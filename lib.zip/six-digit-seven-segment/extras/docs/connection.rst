How to connect the Display
==========================
.. image:: Connect_Display.*
