6-digit-7-Segment Arduino-Library
=================================
Welcome to the documentaion of my `6-digit-7-Segment Arduino-Library`_ - Help yourself!

If you have a quastion please do not hesitate and `ask me`_! :-)

.. |SB| replace:: S\ :sub:`ohny`\ B\ :sup:`ohny`
|SB|
   
.. toctree::
   :maxdepth: 4
   
   View on GitHub <https://github.com/SohnyBohny/6-digit-7-Segment-Arduino>
   install
   usage
   connection

.. _6-digit-7-Segment Arduino-Library: https://github.com/SohnyBohny/6-digit-7-Segment-Arduino
.. _ask me: https://github.com/SohnyBohny/6-digit-7-Segment-Arduino/issues
