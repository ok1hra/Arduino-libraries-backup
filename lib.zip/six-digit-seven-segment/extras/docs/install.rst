How to install & include the library
==========================
1. Download via LibraryManger
--------------------------
* Open Arduino IDE
* goto ``Sketch`` - ``Include Library`` - ``Manage Libraries...``
* install six-digit-seven-segment

2. Include Library
------------------
* add library ``Sketch`` - ``Include Library`` - ``six-digit-seven-segment``
* `check how to use`_


.. _check how to use: usage.html

3. See Examples
---------------
* goto ``File`` - ``Examples`` - ``Display_6-digit-7-Segment``
* If you have a quastion please do not hesitate and `ask me`_! :-)

.. _ask me: https://github.com/SohnyBohny/6-digit-7-Segment-Arduino/issues
