[For more information check my wiki pages](https://6-digit-7-segment-arduino.readthedocs.io "Learn how to use this library")
